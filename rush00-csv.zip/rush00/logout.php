<?php
session_start();
$_SESSION["loggued_on_user"] = "";
header('Location: ./index.php');
?>
